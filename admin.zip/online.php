<?php
        include 'inc/header.php';
        // include 'inc/slider.php';
    ?>




<?php
        include 'inc/footer.php';
    ?>
