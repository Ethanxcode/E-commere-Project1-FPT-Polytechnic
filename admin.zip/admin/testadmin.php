<?php include 'inc/part1.php'; ?>
<?php include 'inc/part2.php'; ?>
<?php include 'inc/part4.php'; ?>